var hrInduction = function(){
    var _this = this;

    this.init = function(){
        console.log("Init function invoked");
        _this.isCorrectlyDropped = false;
        _this.dropCount = 0;
        _this.correctDrop = 0;
        _this.inCorrectDrop = 0;
        _this.getJsonData();
    }

    this.getJsonData = function(){
        $.ajax({
            url : "assets/data/data.json",
            type : "GET",
            cache : false,
            success : _this.loadSuccess,
            error : _this.onLoadError
        });
    }

    this.loadSuccess = function(jdata){
        console.log("Json loaded successfully");
        _this.jsonData = jdata.data;
        console.log(_this.jsonData);
        _this.initStickyNotes();
    }

    this.onLoadError = function(){
        console.log("Error on load json data");
    }

    this.initStickyNotes = function(){
        console.log(_this.jsonData.dragData.length);

        for( let i=0; i<_this.jsonData.dragData.length; i++){
            $(".itemsHolder").append("<div><img src="+_this.jsonData.commonImagePath+_this.jsonData.dragData[i].bgImage+" noteType="+_this.jsonData.dragData[i].category+" id=item"+_this.jsonData.dragData[i].id+" class='dragItems'></div>");
            $("#item"+_this.jsonData.dragData[i].id).addClass("changeStickyNote");
        }

        for(let i=0; i<_this.jsonData.dropData.length; i++){
            $(".binsContainer").append("<div class='bins' id=bay"+_this.jsonData.dropData[i].id+" binType="+_this.jsonData.dropData[i].type+"></div>");
            $(".dropBins").append("<img class='feedbackimages' id=feedBackImg"+_this.jsonData.dropData[i].id+">");
            $("#bay"+_this.jsonData.dropData[i].id).css({
                "background" : "url("+_this.jsonData.commonImagePath+_this.jsonData.dropData[i].image+")",
                "background-size" : "100% 100%"
            });
            $('#feedBackImg'+_this.jsonData.dropData[i].id).addClass("hideFeedback");
        }

        $(".bins").addClass("bin");
        _this.addEvents();
    }

    this.addEvents = function(){

        $(".bins").droppable({
            drop: function(event, ui){
                _this.isCorrectlyDropped = true;
                _this.currentDragElem = $(ui.draggable);
                _this.currentDropElem = $(this);
                _this.checkBin(_this.currentDragElem, _this.currentDropElem);
            }
        });

        $(".dragItems").draggable({
            appendTo: "body",
            containment : $('body'),
            start: function(){
                _this.isCorrectlyDropped = false;
                $(".feedbackimages").addClass("hideFeedback");
            },
            drag : function(){
                $(this).css("z-index","2");
            },
            stop : function(){
                if(_this.isCorrectlyDropped){
                    console.log('Valid Drop');	
				}else{
					console.log('Invalid Drop');
                }
                _this.checkDestination(this);
            }
        });

        this.checkDestination = function(currentItem){
            $(currentItem).css({
                "position" : "relative",
                "top" : "0",
                "left" : "0",
                "right" : "0",
                "bottom" : "0",
            });
        }
    }

    this.checkBin = function(curDragElement,curDropElement){

        _this.dropCount++;
        _this.noteType = $(curDragElement).attr('noteType');
        _this.binType = $(curDropElement).attr('binType');
        _this.curBinId = $(curDropElement).attr('id');
        $(curDropElement).append($(curDragElement));
        $(curDragElement).addClass("hideContent");
        _this.compareBinId  = _this.curBinId.charAt(3);

        if(_this.noteType == _this.binType){
            console.log("Correctly Placed");
            _this.correctDrop++;
            $('#feedBackImg'+_this.compareBinId).attr("src" , _this.jsonData.commonImagePath+_this.jsonData.feedBack.correctFeedback);
            $('#feedBackImg'+_this.compareBinId).removeClass("hideFeedback");
        }else{
            console.log("Incorrectly placed");
            _this.inCorrectDrop++;
            $('#feedBackImg'+_this.compareBinId).attr("src" , _this.jsonData.commonImagePath+_this.jsonData.feedBack.incorrectFeedback);
            $('#feedBackImg'+_this.compareBinId).removeClass("hideFeedback");
        }

        if(_this.dropCount == _this.jsonData.dragData.length){
            console.log("Bin closed: corrctly Placed = "+_this.correctDrop+" Incorrctly Placed = "+_this.inCorrectDrop);
        }
    }
}